const AboutUs=()=>{
    return(
        <div className="min-h-screen bg-grey-100 p-8">
            <h1 className="text-3xl font-bold">Abput our Project</h1>
            <div>
                Lorem ipsum dolor sit amet consectetur, adipisicing elit. In, maxime ipsa delectus dolorum sint architecto error animi sapiente alias quas asperiores dolore magnam molestias natus porro sit sed obcaecati est nemo consequuntur facere minus eius at. Odio voluptate animi accusantium tenetur saepe officia at nisi exercitationem consequatur cumque tempora, velit iure dignissimos delectus laboriosam totam obcaecati libero eveniet ipsa nobis. Ut eos quidem esse hic sapiente! Explicabo similique officia possimus beatae! Voluptas officia accusantium dolores quaerat beatae incidunt accusamus commodi libero repellendus asperiores, aperiam doloremque animi sint atque quas mollitia laudantium ipsam qui recusandae tenetur veniam. Commodi vero consequatur fuga earum dicta dolorum tenetur quam cumque totam est harum a ipsum excepturi accusantium veniam natus aliquam alias, voluptatem culpa ratione? Sequi rerum doloremque nam ipsam, voluptatum quaerat nesciunt debitis nobis eum id voluptas amet accusamus iusto molestias eos consectetur. Necessitatibus incidunt nulla deleniti aut animi ex provident fugiat error ab! Asperiores totam, omnis eveniet repellat suscipit error sapiente quam, non amet odit ab, quas provident labore nihil possimus at id harum ducimus doloribus sed architecto expedita. Dolor, odit. Ea dicta aliquam placeat minima quis, facere voluptatem assumenda doloribus repudiandae iste. Dolore et accusantium unde deserunt, rerum atque vero provident repudiandae?
            </div>

        </div>
    )
}
export default AboutUs;